import Lab3Help.BLineStop;
import Lab3Help.BLineTable;
import Lab3Help.BStop;
import Lab3Help.Path;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class DijkstraStringPath implements Path<String>{

    private DijkstrasAlgorithm<String> dijsktra;

    public DijkstraStringPath(List<BStop> bStops, List<BLineTable> bLineTables){
        ArrayList<String> vertexes = new ArrayList<>();
        ArrayList<Edge> edges = new ArrayList<>();

        for(BStop stop : bStops){
            vertexes.add(stop.getName());
        }

        for (BLineTable bLineTable : bLineTables) {
            BLineStop[] stops = bLineTable.getStops();
            for (int j = 0; j < stops.length; j++) {

                String start, dest;
                int weight = stops[j].getTime();

                if (weight > 0) {
                    start = stops[j - 1].getName();
                    dest =  stops[j].getName();
                    edges.add(new Edge(start, dest, weight));
                } else {
                    start = stops[j].getName();
                    edges.add(new Edge(start, start, weight));
                }
            }
        }

        Graph graph = new Graph(edges, vertexes);

        graph.toString();

        dijsktra = new DijkstrasAlgorithm<>(graph);
    }

    @Override
    public void computePath(String from, String to){
        dijsktra.computePath(from, to);
    }

    @Override
    public Iterator<String> getPath(){
        return dijsktra.getPath(); //while has next?
        //Ger en iterator med noderna längs vägen (om det finns någon) inklusive start- och ändnoderna. Om de inte finns
        //någon väg ska iteratorn vara torm. Om en path hittas är första nodern i iteratorn start och den sista änd.
    }

    @Override
    public int getPathLength(){
        return dijsktra.getPathLength();
    }
}
