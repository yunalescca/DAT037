import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Graph {

    //TODO representera grannlistor
    private List<Edge> edges;
    private List<String> vertexes;
    private Map<String, Vertex> adjList; /* ? Ska String som är namn på nod ligga i Graph fortfarande?
     */

    @SuppressWarnings("unchecked")
    public Graph(List<Edge> edges, List<String> vertexes){
        this.edges = edges;
        this.vertexes = vertexes;
        adjList = new HashMap<>();
        generateVertices();
    }

    private void generateVertices(){
        for(String str : vertexes){
            List<String> adjacent = new ArrayList<>();
            for(Edge edge : edges){
                if(edge.getSource().equals(str)){
                    adjacent.add(str);
                }
            }
            adjList.put(str, new Vertex(adjacent, false));
        }
    }

    public List<Edge> getEdges(){
        return edges;
    }

    public List<String> getVertexes(){
        return vertexes;
    }

    private String getEdge(String name) {
        String string = "";
        for(Edge edge : edges){
            if(edge.getSource().equals(name) || edge.getDestination().equals(name)) {
                string += "Source : " + edge.getSource() + ", dest: " + edge.getDestination() +
                        ", weight: " + edge.getWeight() + "\n";
            }
        }
        return string;
    }

    @Override
    public String toString(){
        System.out.println("VERTEXES");
        for(String vertex : vertexes){
            System.out.println(vertex);
            System.out.println(getEdge(vertex));
        }
        return "";
    }
}
