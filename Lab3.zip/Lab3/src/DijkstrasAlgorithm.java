import Lab3Help.Path;
import java.util.*;

public class DijkstrasAlgorithm<E> implements Path<E> {

    private List<Edge> edges;
    private List<String> vertexes;
    private PriorityQueue<E> priorityQueue;
    private Map<E, Integer> distance;
    private Map<E, E> path;
    private Set<E> k;
    private Iterator<E> iterator;
    private int pathLength;

    public DijkstrasAlgorithm(Graph graph){
        edges = graph.getEdges();
        vertexes = graph.getVertexes();
    }

    @Override
    public void computePath(E from, E to) {
        distance.put(from, 0);
        priorityQueue.add()
        /*

        FÖRELÄSNING
        ===========
        d: lagrar hittils kortaste vägen till alla noder, empty map from node indexes (by default infinity)
        p: lagrar föregående nod för hittills kortaste vägen, empty map from node indexes
        k: lagrar om kortaste vägen till noden är känd, empty set of node indexes
        q: new empty priority queue

        d[s] = 0;
        q.insert(s,0)
        while q is non-empty do
            v = q.delete-min()
            if v not in k then
                insert v into k
                for each direct successor v' of v do
                    if(v' not in k) and d[v'] > d[v] + c(v', v) then
                        d[v'] = d[v] + c(v', v)
                        p[v'] = v
                        q.insert(v', d[v']
        return (d,p)

        BOK
        ===
        void dijkstra (Vertex s)
            for each Vertex v
                v.dist = INFINITY
                v.known = false
            s.dist = 0
            while there is an unknown distance vertex
                Vertex v  = smallest unknown distance vertex
                v.known = true
                for each Vertex w adjacent to v do
                    if(!w.known)
                        int cvw = cost of edge from v to w
                        if(v.dist + cvw < w.dist)
                            //Update w
                            decrease(w.dist to v.dist + cvw)
                            w.path = v
        */
    }

    @Override
    public Iterator<E> getPath() {
        return iterator;
    }

    @Override
    public int getPathLength() {
        return pathLength;
    }
}
