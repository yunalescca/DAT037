import java.util.List;

public class Vertex
{
    private List adj; //Adjacency list
    private boolean known;
    //private Vertex path;
    //other fields and methods as needed

    public Vertex(List adj, boolean known){
        this.adj = adj;
        this.known = known;
    }
}