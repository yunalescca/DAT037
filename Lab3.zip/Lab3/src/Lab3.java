import Lab3Help.*;

import java.io.IOException;
import java.util.List;

public class Lab3 {

    //TODO: Ordning? Dijkstra eller grannlistor? Ska grannlistorna användas i Dijsktra eller vart kommer de in i bilden?
    //Ska det finnas mer i Dijsktra än pseudokoden vi fick? Ska konstruktorn i Graph ändras?

    /*
    Hållplatsfiler kan läsas in med metoden readStops i klassen Lab3File.
    Metoden readStops ger en lista som innehåller element av typen BStop.
    De här elementen representerar hållplatser och innehåller namn samt koordinater.

    Linjefiler kan läsas in med readLines, också i klassen Lab3File, vars resultat är en
    lista med element av typen BLineTable. Varje BLineTable representerar information om
    en linje och innehåller linjens nummer samt de hållplatser som ingår i linjen. Dessa
    hållplatser representeras av objekt/värden av typen BLineStop, som innehåller hållplatsens
    namn samt den tid det tar att ta sig till hållplatsen från föregående hållplats.
     */
    @SuppressWarnings("unchecked")
    public static void main(String[] args){
        Lab3File lab3File = new Lab3File();

        try {
            //List<BStop> bStops = lab3File.readStops(args[0]);
            //List<BLineTable> bLineTables = lab3File.readLines(args[1]);
            //String start = args[2];
            //String end   = args[3];
            List<BStop> bStops = lab3File.readStops("stops-gbg.txt");
            List<BLineTable> bLineTables = lab3File.readLines("lines-gbg.txt");
            String start = "Angered";
            String end = "Botaniska";

            Path path = new DijkstraStringPath(bStops, bLineTables);
            //new GUI(bStops, bLineTables, path);

            path.computePath(start, end);

            if(path.getPath() == null){
                System.out.println("Det finns ingen väg mellan " + start + " och " + end);
            } else if(start.equals(end)){
                System.out.println(path.getPathLength() + "\n" + start);
            } else {
                System.out.println(path.getPathLength() + "\n");
                //TODO: Lista alla hållplatser vi åker förbi, inklusive start- och ändhållplatsen
            }

        } catch (MalformedData malformedData) {
            malformedData.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
